#!/system/bin/sh
# aemu-modhost-test: proves the offline host ran this module's service script
echo "aemu-modhost-test service ran, MODDIR=$MODDIR" > /data/local/tmp/aemu-modhost-test-service.ran
